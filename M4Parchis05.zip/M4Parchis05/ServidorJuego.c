#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <mysql.h>
#include <pthread.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;



typedef struct {
	char nombre[2000];
	int socket;	
}Conectado;

typedef struct {
	Conectado listaConectado[500];
	int num;
}ListaConectados;

typedef struct {
	int Id;
	Conectado listaPartida[500];
	int num;
}Partida;

typedef struct {
	Partida listaPartidas[500];
	int num;
}ListaPartidas;

char ubicacion[20];
int i = 0;
int sockets[100];
ListaConectados listaConect;
ListaPartidas listaParti;

void InicializarListas(){
	listaConect.num = 0;
	listaParti.num = 0;
}

int AfegirConnectat(ListaConectados *lista, char nombre[20], int socket){
    if (lista->num==10){
        return -1;
    }else{
        strcpy(lista->listaConectado[lista->num].nombre,nombre);
		lista->listaConectado[lista->num].socket=socket;
        lista->num++;
        return 0;
    }
}

int Dame_Posicion(ListaConectados *lista, char nombre[20]){
	int encontrado=0,i=0;
	while(encontrado==0||i<100){
		if(strcmp(lista->listaConectado[i].nombre,nombre)==0)
			encontrado=1;
		else i++;
	}
	if(encontrado=1){
		return i;
	}
	else 
	   return -1;
}


int Eliminar_Conectado(ListaConectados *lista, char nombre[20]){
    int pos = Dame_Posicion(lista,nombre);
    if(pos==-1){
        return -1;
    }else{
        int i;
        for(i=pos;i<lista->num-1;i++){
            lista->listaConectado[i]=lista->listaConectado[i+1];
            //lista->conectados[i].socket=lista->conectados[i+1].socket;
        }
        lista->num--;
        return 0;
    }
}

int EstaConectado(ListaConectados *lista, char nombreUsuario[20]){
    int i;
    for(i=0;i<lista->num;i++){
        if(strcmp(lista->listaConectado[i].nombre,nombreUsuario) == 0){
            return 0;
        }
    }
    return -1;
}

int Dame_Socket(ListaConectados *lista, char nombre[20]){
    int i=0;
    int encontrado=0;
    while((i<lista->num) && !encontrado){
        if(strcmp(lista->listaConectado[i].nombre,nombre)==0){
            encontrado=1;
        }else
           i++;
    }
    if(encontrado){
        return lista->listaConectado[i].socket;
    }else return -1;
}


//Funcion para checkear los usuarios conectados actualmente
//Hace un recorrido devolviendo un 'sprintf' con los nombres de los usuarios conectados
void DameConectados(ListaConectados *lista, char listaConectado[300]){
    sprintf(listaConectado,"%d", lista->num);
    int i;
    for(i=0;i<lista->num;i++){
        sprintf(listaConectado,"%s/%s", listaConectado, lista->listaConectado[i].nombre);
    }
}

void EnviarConectados(char mensaje[500]){
	char conectados[512];
	char connected[512];
	pthread_mutex_lock(&mutex);
	DameConectados(&listaConect, conectados);
	pthread_mutex_unlock(&mutex);
	sprintf(connected,"%s",conectados);
	char *pi = strtok(connected, "/");
	int n = atoi(pi);
	printf("Personas conectadas: %d\n", n);
	int i;
	for(i=0;i<n;i++){
		char nombre[20];
		pi =strtok(NULL,"/");
		strcpy(nombre,pi);
		printf("Conectado: %s\n", nombre);
	}
	
	sprintf(mensaje, "6/%s", conectados);
	printf("\n%s\n", mensaje);
}

void *AtenderCliente (void *socket)
{
	
	//strcpy(ubicacion, "localhost");
	strcpy(ubicacion, "shiva2.upc.es");
	
	char nomUsuario[20];
	char contra[20];
	char correo[50];
	int ret;
	int retorno,conectado=0;
	char buff[512];
	char peticion [512];
	char res[512];
	int sock_conn = *((int *) socket);
	printf("Te doy el socket %d\n", sock_conn);
	
	//Inicio el MYSQL
	MYSQL *conn;
	int err;
	// Estructura necessaria para acesso excluyente
	pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
	
	// Estructura especial para almacenar resultados de consultas 
	MYSQL_RES *resultado;
	MYSQL_ROW row;
	//Creamos una conexion al servidor MYSQL 
	conn = mysql_init(NULL);
	if (conn==NULL) {
		printf ("Error al crear la conexi\ufff3n: %u %s\n", 
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	//inicializar la conexion
	conn = mysql_real_connect (conn, ubicacion,"root", "mysql", "M4_BBDDParchis",0, NULL, 0);
	if (conn==NULL) {
		printf ("Error al inicializar la conexion: %u %s\n", 
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}	
	
	int terminar = 0;	
	
	//Entramos en un bucle para atender todas las peticiones de este cliente.
	//Hasta que se desconecte
	while(terminar==0)
	{
		
		// Ahora recibimos su nombre, que dejamos en buff
		ret=read(sock_conn,buff, sizeof(buff));
		printf ("Recibido\n");
		
		// Tenemos que a?adirle la marca de fin de string 
		// para que no escriba lo que hay despues en el buffer
		buff[ret]='\0';
		
		//Escribimos el nombre en la consola		
		printf ("Se ha conectado: %s\n",buff);
		
		char *p = strtok( buff, "/");
		int codigo =  atoi (p);	
		
		//Usuario se desconecta y se elimina de la lista de conectados
		if (codigo == 0) {
			

			p = strtok(NULL, "/");
			strcpy(nomUsuario, p);
			
			int eliminar = Eliminar_Conectado(&listaConect, nomUsuario);	
			close(sock_conn);
			terminar = 1;			
		}
		
		//Usuario se registra y se añade a la lista de conectados
		if (codigo == 1)
		{
			
			p= strtok(NULL, "/");
			strcpy(correo, p);
			
			p= strtok(NULL, "/");
			strcpy(nomUsuario, p);
			
			p= strtok(NULL, "/");
			strcpy(contra, p);
			
			//Comprobo que el usuario no existeix
			pthread_mutex_lock(&mutex);
			
			char consulta [1000];
			char consulta2 [1000];
			strcpy(consulta, "SELECT * FROM Usuario WHERE Nombre_Usuario = '");
			strcat(consulta, nomUsuario);
			strcat(consulta, "';");
			
			err = mysql_query (conn, consulta);
			if(err!=0){
				printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
				
				exit (1);
			}
			//Recollim el resultat de la consulta.
			resultado = mysql_store_result(conn);
			//ahora busco la fila de del usuario.
			row = mysql_fetch_row (resultado);
			int n_rows = mysql_num_rows(resultado);
			
			
			
			
			//si la contrasenya i el nom d'usuari son correctes no sera null.
			if(n_rows == 0)
			{
				strcpy(buff, "1/0");
				
				
				
				//Afegeixo el usuari a la base de dades
				char consulta [1000];
				char consulta2 [1000];
				
				strcpy(consulta, "INSERT INTO Usuario (Nombre_Usuario, Correo, Passwd, Victorias) VALUES ('");
				strcat(consulta, nomUsuario);
				strcat(consulta, "', '");
				strcat(consulta, correo);
				strcat(consulta, "', '");
				strcat(consulta, contra);
				strcat(consulta, "', '0');");
				
				err = mysql_query (conn, consulta);
				if(err!=0){
					printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
					
					exit (1);
				}
				//Recollim el resultat de la consulta.
				resultado = mysql_store_result(conn);
				
				printf("Usuario registrado con exito!\n");
				int add = AfegirConnectat(&listaConect,nomUsuario,sock_conn);
				
			}
			else
			{
				strcpy(buff, "1/-1");
				printf("Ja existeix aquest usuari!\n");
			}
			
			// Y lo enviamos
			write (sock_conn, buff, strlen(buff));
			
			EnviarConectados(peticion);
			for(int i=0;i<listaConect.num;i++){
				write(listaConect.listaConectado[i].socket, peticion, strlen(peticion));
			}
			
			pthread_mutex_unlock(&mutex);
			
		}
		//El usuario inicia sesión y se añade a la lista de conectados
		if(codigo ==2)
		{			
			p= strtok(NULL, "/");
			strcpy(nomUsuario, p);
			
			p= strtok(NULL, "/");
			strcpy(contra, p);
						
			pthread_mutex_lock(&mutex);
			
			
			char consulta [1000];
			char consulta2 [1000];
			strcpy(consulta, "");
			strcpy(consulta2, "");
			
			// Se verifica que el exista el usuario, y que las credenciales sean válidas.
			strcpy(consulta, "SELECT Nombre_Usuario FROM Usuario WHERE Nombre_Usuario = '");
			strcat(consulta, nomUsuario);
			strcat(consulta, "' AND Passwd = '");
			strcat(consulta, contra);
			strcat(consulta, "';");
			
			err = mysql_query (conn, consulta);
			if(err!=0){
				printf ("Error al consultar datos de la base %u %s\n", mysql_errno(conn), mysql_error(conn));
				
				exit (1);
			}
			//Recollim el resultat de la consulta.
			resultado = mysql_store_result(conn);
			//ahora busco la fila de del usuario.
			row = mysql_fetch_row (resultado);			
			
			if(row == NULL){
				strcpy(buff, "2/-1");
				printf("No hi es!!!");
			}
			else{
				
				int estaConectado = EstaConectado(&listaConect,nomUsuario);
				if(estaConectado == 0){
					strcpy(buff, "2/-2");
				}
				else{
					strcpy(buff, "2/0");
					printf("Trobat!!\n");					
					int add = AfegirConnectat(&listaConect,nomUsuario,sock_conn);
					}
			}
				
			// Y lo enviamos
			write (sock_conn, buff, strlen(buff));
			
			EnviarConectados(peticion);
			for(int i=0;i<listaConect.num;i++){
				write(listaConect.listaConectado[i].socket, peticion, strlen(peticion));
			}
			
			pthread_mutex_unlock(&mutex);					
		}
		
	
			
	}		
}

int main(int argc, char *argv[])
{
	//strcpy(ubicacion, "localhost");
	strcpy(ubicacion, "shiva2.upc.es");
	//Inicio el MYSQL
	MYSQL *conn;
	int err;
	// Estructura necessaria para acesso excluyente
	pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
	
	// Estructura especial para almacenar resultados de consultas 
	MYSQL_RES *resultado;
	MYSQL_ROW row;
	//Creamos una conexion al servidor MYSQL 
	conn = mysql_init(NULL);
	if (conn==NULL) {
		printf ("Error al crear la conexi\ufff3n: %u %s\n", 
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}
	//Inicializar la conexión
	conn = mysql_real_connect (conn, ubicacion, "root", "mysql", "M4_BBDDParchis",0, NULL, 0);
	if (conn==NULL) {
		printf ("Error al inicializar la conexion: %u %s\n", 
				mysql_errno(conn), mysql_error(conn));
		exit (1);
	}	
	
	int sock_conn, sock_listen, ret;
	struct sockaddr_in serv_adr;
	char buff[512];
	char buff2[512];
	// INICIALITZACIONS
	// Obrim el socket
	if ((sock_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		printf("Error creant socket");
	// Fem el bind al port
	
	
	memset(&serv_adr, 0, sizeof(serv_adr));// inicialitza a zero serv_addr
	serv_adr.sin_family = AF_INET;
	
	// asocia el socket a cualquiera de las IP de la m?quina. 
	//htonl formatea el numero que recibe al formato necesario
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	//50016
	serv_adr.sin_port = htons(50016);
	
	
	if (bind(sock_listen, (struct sockaddr *) &serv_adr, sizeof(serv_adr)) < 0)
		printf ("Error al bind");
	//La cola de peticiones pendientes no podr? ser superior a 4
	if (listen(sock_listen, 2) < 0)
		printf("Error en el Listen");	
	
	InicializarListas();
	
	int terminar = 0;
	
	pthread_t thread;
	
	// Atenderemos solo 5 clientes
	while(terminar == 0){
		printf ("Escuchando\n");
		
		sock_conn = accept(sock_listen, NULL, NULL);
		printf ("He recibido conexion\n");
		//sock_conn es el socket que usaremos para este cliente
			
	
		sockets[i] = sock_conn;
		Conectado nuevaConex;
		
		
		//Creat thead y decirle lo que tinene que hacer
		pthread_create (&thread, NULL, AtenderCliente, &sockets[i]); 
		i++;
	}
}
